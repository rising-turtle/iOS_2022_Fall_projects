//
//  iOS_Proj2App.swift
//  Shared
//
//  Created by graceerk on 11/6/22.
//

import SwiftUI

@main
struct iOS_Proj2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
