//
//  ContentView.swift
//  Shared
//
//  Created by graceerk on 11/6/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, test!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
