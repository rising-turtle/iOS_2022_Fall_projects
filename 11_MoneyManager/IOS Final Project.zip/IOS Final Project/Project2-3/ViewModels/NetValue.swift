//
//  NetValue.swift
//  Project2-3
//
//  Created by Jonathan Homa on 12/7/22.
//

import Foundation
import SwiftUICharts

class WeeklyNetTotal: ObservableObject{
    @Published var WeeklyNets = [Double]()
    let startingVal = 0.0
    init(){
        
        for i in 1..<53{
            WeeklyNets.append(startingVal)
        }
        print(WeeklyNets.count)
    }
}




