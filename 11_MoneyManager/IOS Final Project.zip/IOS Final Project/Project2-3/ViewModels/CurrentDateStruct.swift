//
//  CurrentDateStruct.swift
//  Project2-3
//
//  Created by Jonathan Homa on 12/7/22.
//

import Foundation

 class CurrentDate: ObservableObject{
     @Published var currDate = Date.now
}

