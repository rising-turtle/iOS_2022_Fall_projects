//
//  DataViewModel.swift
//  Project2-3
//
//  Created by Jonathan Homa on 12/5/22.
//

import Foundation

struct Entry : Codable, Hashable, Identifiable{
    var id: UUID?
    var Category: String
    var Price : Double
}

struct CompleteEntry: Identifiable, Decodable{
    var id: UUID?
    var Week : Int
    var WeeklyNet: Double
    var Entries : [Entry]
    
}

struct allItems : Decodable{
    var Items : [CompleteEntry]
}


class DataViewModel : ObservableObject{
    var results = [CompleteEntry]()
    init(){
        readJSONFile()
    }
    
    func readJSONFile(){
        // 1. pathString
        let pathString = Bundle.main.path(forResource: "testData", ofType: "json")
        if let path = pathString{
            // 2. URL
            let url = URL(fileURLWithPath: path)
            // 3. Data object
            do{
                let data = try Data(contentsOf: url)
                // 4. json decoder
                let jsonDecoder = JSONDecoder()
                // 5. get json data
                // var jsonData = try jsonDecoder.decode([People].self, from: data)
                var jsonData = try jsonDecoder.decode(allItems.self, from: data)
                for i in 0..<jsonData.Items.count {
                    jsonData.Items[i].id = UUID()
                }
                results = jsonData.Items
            } catch{
                print(error)
            }
        }else{
        }
}
    
    func writeToJson(){
        DispatchQueue.main.async {
            
        
        var TopLevel : [AnyObject] = []
        for Entries in self.results{
            var WeekDict: [String: AnyObject] = [:]
            //WeekDict["id"] = NSNumber(value: Entries.id)
            WeekDict["Week"] = NSNumber(value: Entries.Week)
            WeekDict["WeeklyNet"] = NSNumber(value: Entries.WeeklyNet)
            var Values : [AnyObject] = []
            for entriesList in Entries.Entries{
                var entryDict: [String: AnyObject] = [:]
                entryDict["Category"] = NSString(utf8String: entriesList.Category)
                entryDict["Price"] = NSNumber(value: entriesList.Price)
                Values.append(entryDict as AnyObject)
            }
            WeekDict["Entries"] = Values as AnyObject
            TopLevel.append(WeekDict as AnyObject)
        }
        do{
            let jsonData = try JSONSerialization.data(withJSONObject: TopLevel, options: .prettyPrinted)
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first{
                let url = documentDirectory.appendingPathComponent("testData.json")
                try jsonData.write(to: url)
                print(url)
            }
        }catch{
            print(error)
        }
    }
    }
}




