//
//  AddSpendingView.swift
//  Project2-3
//
//  Created by David Terzano on 11/15/22.
//

import SwiftUI


struct AddSpendingView: View {
    
    @State var spendingName : String = ""
    @State  var spendingAmnt = 0.0
    private let numberFormatter : NumberFormatter
    @EnvironmentObject var SpendingVM : SpendingViewModel
    @EnvironmentObject var selectedDate : CurrentDate
    @EnvironmentObject var weeklyNets : WeeklyNetTotal
    var currWeek: Int {
        return Calendar.current.component(.weekOfYear, from: selectedDate.currDate)
    }
    
    init() {
        numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .currency
        numberFormatter.maximumFractionDigits = 2
    }
    
    var body: some View {
        VStack {
        Text("Add Spending Item Name and Price:")
            HStack {
                TextField("Item Name", text: $spendingName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
             
                TextField("$0.00", value: $spendingAmnt, formatter: numberFormatter)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .keyboardType(.decimalPad)
                    .padding()
            }
        
           // Text("\($spendingName)")
            
            Button{
                //action
                print($spendingAmnt)
                let toAdd = SpendingEntry(Category: spendingName, Price: spendingAmnt)
                //print(toAdd)
                //SpendingVM.results[currWeek-1].Entries.append(toAdd)
                SpendingVM.results[currWeek-1].Entries.append(toAdd)
                SpendingVM.results[currWeek-1].WeeklyNet -= toAdd.Price
                weeklyNets.WeeklyNets[currWeek-1] -= toAdd.Price
                SpendingVM.objectWillChange.send()
                print(SpendingVM.results[currWeek-1].Entries.count)

            } label: {
                ZStack{
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color.white)
                        .shadow(radius: 5)
                        .frame(width: 200, height: 40, alignment: .center)
                    
                    Text("Add Item")
                        .padding()
                        .frame(alignment: .leading)
                    Spacer()
                }.frame(width: 200, height: 20, alignment: .center).padding()
                
            }.padding(.bottom)
        }
    }
}

struct AddSpendingView_Previews: PreviewProvider {
    static var previews: some View {
        AddSpendingView().environmentObject(SpendingViewModel())//.environmentObject(WeeklyNetTotal()).environmentObject(CurrentDate())
            //.environmentObject(DataViewModel())
            //.environmentObject(SpendingViewModel())
    }
}
