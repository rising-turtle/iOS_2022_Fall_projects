//
//  ChartView.swift
//  Project2-3
//
//  Created by Jonathan Homa on 12/8/22.
//

import SwiftUI
import SwiftUICharts
struct ChartView: View {
    
    let chartStyle : ChartStyle = ChartStyle(backgroundColor: .white, accentColor: .black, gradientColor: .init(start: .red, end: .green), textColor: .black, legendTextColor: .black, dropShadowColor: .black)
    @EnvironmentObject var weeklyNets : WeeklyNetTotal
    @EnvironmentObject var selectedDate : CurrentDate
    var currWeek: Int {
        return Calendar.current.component(.weekOfYear, from: selectedDate.currDate)
    }

    var body: some View {
        VStack(alignment: .center, spacing: 50){
            LineView(data: weeklyNets.WeeklyNets, title: "Net Values Over Time", style: chartStyle).padding()
        }
    }
}

struct ChartView_Previews: PreviewProvider {
    static var previews: some View {
        ChartView().environmentObject(WeeklyNetTotal())
    }
}
