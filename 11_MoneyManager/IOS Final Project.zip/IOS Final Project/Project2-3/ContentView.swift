//
//  ContentView.swift
//  Project2-3
//
//  Created by Jonathan Homa on 11/11/22.
//

import SwiftUI
//test comment
struct ContentView: View {
    @StateObject var model = CurrentDate()
    @StateObject var IncomeModel = DataViewModel()
    @StateObject var SpendingModel = SpendingViewModel()
    @StateObject var WeeklyNetValue = WeeklyNetTotal()
    
    //@StateObject var ChartModel = ChartData()
    var body: some View {
        

        TabView{
            OverviewTab().tabItem{
                Image(systemName: "chart.bar.fill")
                Text("Overview")
            }.environmentObject(model).environmentObject(SpendingModel).environmentObject(IncomeModel).environmentObject(WeeklyNetValue)
            IncomeTab().tabItem{
                Image(systemName: "chart.line.uptrend.xyaxis")
                Text("Income")
            }.environmentObject(model).environmentObject(IncomeModel).environmentObject(WeeklyNetValue)
            SpendingTab().tabItem{
                Image(systemName: "dollarsign.circle")
                    .foregroundColor(Color.red)
                Text("Spending")

            }.environmentObject(model).environmentObject(SpendingModel)
                .environmentObject(WeeklyNetValue)

        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
