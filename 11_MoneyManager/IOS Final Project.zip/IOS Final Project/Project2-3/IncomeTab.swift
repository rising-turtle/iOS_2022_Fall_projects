//
//  IncomeTab.swift
//  Project2-3
//
//  Created by Jonathan Homa on 11/11/22.
//

import SwiftUI
let currDate = Date()
let currCal = Calendar.current
let dayOfWeek = Calendar.current.component(.weekday, from: Date())
let weekdays = Calendar.current.range(of: .weekday, in: .weekOfYear, for: Date())
//let days = ((weekdays?.lowerBound ?? 0) ..< weekdays?.upperBound!)


extension Date {
    var startOfWeek : Date? {
        let gregorian = Calendar(identifier: .gregorian)
        guard let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self)) else{ return nil}
        return gregorian.date(byAdding:.day, value: 0, to: sunday)
    }
    var endOfWeek: Date?{
        let gregorian = Calendar(identifier: .gregorian)
        guard let sunday = gregorian.date(from: gregorian.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self)) else{ return nil}
        return gregorian.date(byAdding:.day, value: 6, to: sunday)
    }
    func getWeekInterval(start: Date, end: Date) -> String{
        let dateFormat = DateIntervalFormatter()
        dateFormat.dateStyle = .short
        dateFormat.timeStyle = .none
        return dateFormat.string(from: start, to: end)
    }
}

struct IncomeTab: View {
   
    let dateFormat = DateFormatter()
    @EnvironmentObject var IncomeVM : DataViewModel
    @EnvironmentObject var selectedDate: CurrentDate
    @EnvironmentObject var weeklyNets :WeeklyNetTotal
    let screenSize : CGRect = UIScreen.main.bounds
    var currWeek: Int {
        return Calendar.current.component(.weekOfYear, from: selectedDate.currDate)
    }
    var weekStart: Date? {
        return selectedDate.currDate.startOfWeek
    }
    var weekEnd: Date? {
        return selectedDate.currDate.endOfWeek
    }
    var weekDisplay: String{
        return selectedDate.currDate.getWeekInterval(start: weekStart!, end: weekEnd!)
    }
    var body: some View {
        NavigationView{
        VStack(alignment: .leading){
            ZStack(alignment: .leading){
                RoundedRectangle(cornerRadius: 5)
                    .foregroundColor(Color.white)
                    .shadow(radius: 1)
                    .frame(width: screenSize.width, height: 40,alignment: .center)
                    //.padding()
                
                DatePicker(selection: $selectedDate.currDate, displayedComponents: .date ){
                        Text("\(weekDisplay)")
                        .font(.body)
                        .id(selectedDate.currDate)
                        .frame(alignment: .leading)
                    }.padding()
            }
           
            HStack{
                Text("Total For week: ")
                    .padding(.horizontal)
                Text("\(String(format: "%.2f", IncomeVM.results[currWeek-1].WeeklyNet))")
                    .foregroundColor(Color.green)
            }.padding()
            
            ZStack(alignment: .center){
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: screenSize.width, height: 300, alignment: .center)
                    .foregroundColor(Color.white)
                    .shadow(radius: 1)
                        
                        ScrollView{
                            ForEach(IncomeVM.results[currWeek-1].Entries, id: \.self){ test in
                        ZStack{
                            RoundedRectangle(cornerRadius: 5)
                                .foregroundColor(Color.white)
                                .frame(width: 290, height: 30)
                            Divider()
                                .padding(.top, 40)
                            
                            HStack{
                                Text("\(test.Category)")
                                    .padding()
                                Spacer()
                                Text("\(String(format:"%.2f", test.Price))")
                                Button{
                                    weeklyNets.WeeklyNets[currWeek-1] -= test.Price
                                    IncomeVM.results[currWeek-1].WeeklyNet -= test.Price
                                    IncomeVM.results[currWeek-1].Entries.remove(at:IncomeVM.results[currWeek-1].Entries.firstIndex(of: test)!)
                                    IncomeVM.objectWillChange.send()
                                    IncomeVM.writeToJson()
                                    print(IncomeVM.results[currWeek-1].Entries.count)
                                }label: {
                                    Image(systemName: "x.circle.fill")
                                        .padding()
                                }
                            }
                        }
                    }
                }.padding()
            }.frame(alignment: .center)
        //}
            NavigationLink{
                AddIncomeView().environmentObject(IncomeVM).environmentObject(weeklyNets)
            
            } label: {
                ZStack{
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color.white)
                        .shadow(radius: 1)
                        .frame(width: 200, height: 40, alignment: .center)
                    
                    Text("Add Earnings")
                        .padding()
                        .frame(alignment: .leading)
                    Spacer()
                }.frame(width: 200, height: 20, alignment: .center).padding()
                
            }.padding(.bottom)
        
        }.navigationBarHidden(true)
        }
    }
}


struct IncomeTab_Previews: PreviewProvider {
    static var previews: some View {
        IncomeTab().environmentObject(CurrentDate()).environmentObject(DataViewModel())
            .environmentObject(WeeklyNetTotal())
    }
}

