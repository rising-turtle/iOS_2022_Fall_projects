//
//  OverviewTab.swift
//  Project2-3
//
//  Created by Jonathan Homa on 11/11/22.
//

import SwiftUI
import SwiftUICharts






struct OverviewTab: View {
    let chartHeight = CGFloat(200)
    let chartWidth = CGFloat(300)
    let scrollHeight = CGFloat(150)
    let scrollWidth = CGFloat(320)
    let startAmount = 500.0
    let dataValues : [Double] = [400, 550, 550, 400, 100, -200, -200, 350]
    let chartStyle : ChartStyle = ChartStyle(backgroundColor: .white, accentColor: .black, gradientColor: .init(start: .red, end: .green), textColor: .black, legendTextColor: .black, dropShadowColor: .black)
    let testStyle = ChartStyle(formSize: CGSize(width: 300, height: 100))
    
    
    
    
    let dateFormat = DateFormatter()
    @EnvironmentObject var SpendingVM : SpendingViewModel
    @EnvironmentObject var IncomeVM: DataViewModel
    @EnvironmentObject var selectedDate: CurrentDate
    //@EnvironmentObject var chartPoints: ChartData
    @EnvironmentObject var WeeklyNets: WeeklyNetTotal
    let screenSize : CGRect = UIScreen.main.bounds
    var currWeek: Int {
        return Calendar.current.component(.weekOfYear, from: selectedDate.currDate)
    }
    var weekStart: Date? {
        return selectedDate.currDate.startOfWeek
    }
    var weekEnd: Date? {
        return selectedDate.currDate.endOfWeek
    }
    var weekDisplay: String{
        return selectedDate.currDate.getWeekInterval(start: weekStart!, end: weekEnd!)
    }
    
    var body: some View {
        
        NavigationView{
        VStack(alignment: .leading){
            //Total header ZStack (text inside rect)
            ZStack(alignment: .leading){
                RoundedRectangle(cornerRadius: 5)
                    .foregroundColor(Color.white)
                    .shadow(radius: 1)
                    .frame(width: scrollWidth ,height: 40, alignment: .center)
                DatePicker(selection: $selectedDate.currDate, displayedComponents: .date ){
                    Text("\(weekDisplay)")
                    .font(.body)
                    .frame(alignment: .leading)
                }.padding()
                /*Text("Total: 500.00")
                    .font(.title)
                    .padding()
                    .frame(alignment: .leading)*/
            }.padding()
            //Title For Scroll view ouside of scroll view
            Text("Net totals by week:")
                .padding(.horizontal)
                .frame(width: 200)
            //ZStack for scroll view to show net amounts
            ZStack(alignment: .center){
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color.white)
                    .shadow(radius: 1)
                    .frame(width: screenSize.width, height: scrollHeight, alignment: .center)
                
                ScrollView{
                    ForEach(0..<WeeklyNets.WeeklyNets.count){ test in
                        ZStack{
                            HStack{
                                Text("Week: \(test)")
                                Spacer()
                                Text("\(String(format: "%.2f", WeeklyNets.WeeklyNets[test]))")
                                    .padding(.top)
                                    .foregroundColor(WeeklyNets.WeeklyNets[test] >= 0 ? Color.green : Color.red)
                                    
                            }.padding(.horizontal)
                        }
                    }
                }.frame(width: scrollWidth, height: scrollHeight, alignment: .center)
            }.padding(.horizontal)
            //ZStack for the chart
            
                
                NavigationLink{
                    ChartView().environmentObject(WeeklyNets)
                } label: {
                    ZStack(alignment: .center){
                   
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color.white)
                        .shadow(radius: 1)
                        .frame(width: screenSize.width, height: 50, alignment: .center)
                    Text("View Chart")
                }
                //LineChartView(data: WeeklyNets.WeeklyNets, title: "Weekly Nets", legend: "Explains", style: chartStyle  ,form: CGSize(width: 300, height: 200), dropShadow: false)
                //LineView(data: WeeklyNets.WeeklyNets, title: "Test", style: testStyle).padding()
            
                
            }.padding()
        }.navigationBarHidden(true)
        }.navigationBarHidden(true)
    }
}

struct OverviewTab_Previews: PreviewProvider {
    static var previews: some View {
        OverviewTab().environmentObject(CurrentDate()).environmentObject(SpendingViewModel()).environmentObject(DataViewModel()).environmentObject(WeeklyNetTotal())
    }
}


//need to double check if this is actually used anywhere

//function that sets up the chart
/*func makeChart(currWeek: Int, SpendingVM: SpendingViewModel, chartPoints: ChartData) -> LineChartData{
    let startingAmount : Double = 500
    //Chart data points
    print("running make chart")
    
    let data = LineDataSet(dataPoints: chartPoints.datapoints,
        legendTitle: "Test",
        pointStyle: PointStyle(),
                           style: LineStyle(lineColour: ColourStyle(colours: [Color.green.opacity(0.9), Color.red.opacity(0.5)], startPoint: .top, endPoint: .bottom), lineType: .line))
        
    //chart titles
    let chartMeta = ChartMetadata(
        title: "Net Spending Over Time",
        titleFont: .title3)
    
    //chart grid
    let gridStyle = GridStyle(numberOfLines: 7, lineColour: Color.gray, lineWidth: 1, dash: [7], dashPhase: 0)
    
    //chart style 
    let chartStyle = LineChartStyle(
        infoBoxPlacement: .infoBox(isStatic: false),
        infoBoxContentAlignment: .vertical,
        
        infoBoxBorderColour: Color.primary,
        infoBoxBorderStyle: StrokeStyle(lineWidth: 1),
        markerType: .vertical(attachment: .line(dot: .style(DotStyle()))),
        
        xAxisGridStyle: gridStyle,
        xAxisLabelPosition: .bottom,
        xAxisLabelColour: Color.black,
    
        //xAxisLabelsFrom: .chartData(rotation: .degrees(0)),
        xAxisTitle: "Week",
        xAxisTitleColour: Color.black,
       
        
        yAxisGridStyle: gridStyle,
        yAxisLabelPosition: .leading,
        yAxisNumberOfLabels: 5,
        yAxisTitle: "Total",
        yAxisTitleColour: Color.black,
        
        
        baseline: .minimumWithMaximum(of: 0),
        topLine: .maximum(of: startingAmount * 2))
        let chartData = LineChartData(dataSets: data, metadata: chartMeta, chartStyle: chartStyle)
    return chartData
}*/



