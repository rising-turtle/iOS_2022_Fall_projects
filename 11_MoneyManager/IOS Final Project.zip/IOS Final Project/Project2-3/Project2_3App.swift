//
//  Project2_3App.swift
//  Project2-3
//
//  Created by Jonathan Homa on 11/11/22.
//

import SwiftUI

@main
struct Project2_3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
