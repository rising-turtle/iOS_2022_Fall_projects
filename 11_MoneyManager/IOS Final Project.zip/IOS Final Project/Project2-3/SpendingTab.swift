//
//  SpendingTab.swift
//  Project2-3
//
//  Created by Jonathan Homa on 11/11/22.
//

import SwiftUI

class SpendingItem {
    var name : String
    var price : Double
    
    init(name: String, price: Double) {
        self.name = name
        self.price = price
    }
}

struct SpendingTab: View {

    @EnvironmentObject var SpendingVM : SpendingViewModel
    

    @EnvironmentObject var selectedDate: CurrentDate
    @EnvironmentObject var weeklyNets : WeeklyNetTotal
    let screenSize : CGRect = UIScreen.main.bounds
    
    
    var currWeek: Int {
        return Calendar.current.component(.weekOfYear, from: selectedDate.currDate)
    }
    var weekStart: Date? {
        return selectedDate.currDate.startOfWeek
    }
    var weekEnd: Date? {
        return selectedDate.currDate.endOfWeek
    }
    var weekDisplay: String{
        return selectedDate.currDate.getWeekInterval(start: weekStart!, end: weekEnd!)
    }
    var body: some View {
        NavigationView {
        VStack(alignment: .leading){
            ZStack(alignment: .leading){
                RoundedRectangle(cornerRadius: 5)
                    .foregroundColor(Color.white)
                    .shadow(radius: 1)
                    .frame(width: screenSize.width, height: 40, alignment: .center)
                    //.padding()
                DatePicker(selection: $selectedDate.currDate, displayedComponents: .date ){
                    Text("\(weekDisplay)")
                    .font(.body)
                    .id(selectedDate.currDate)
                    .frame(alignment:.leading)
                }.padding()
                
            }
            
            HStack {
                Text("Total For week: ")
                    .padding(.horizontal)
                Text("\(String(format: "%.2f", SpendingVM.results[currWeek-1].WeeklyNet))")
                    .foregroundColor(.red)
                    
            }.padding()
            ZStack(alignment: .center){
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: screenSize.width, height: 300, alignment: .center)
                    .foregroundColor(Color.white)
                    .shadow(radius: 1)
                 
                    ScrollView{
                    
                        ForEach(SpendingVM.results[currWeek-1].Entries, id: \.self){ test in
                    ZStack {
                        RoundedRectangle(cornerRadius: 5)
                            .foregroundColor(Color.white)
                            .frame(width: 290, height: 30,alignment: .center)
                        Divider()
                            .padding(.top, 40)
                        
                        HStack {
                            
                            Text("\(test.Category)")
                                    .padding()
                                Spacer()
                            Text("\(String(format:"%.2f", test.Price))")
                                    .padding()
                                    .foregroundColor(.red)
                            Button{
                                weeklyNets.WeeklyNets[currWeek-1] += test.Price
                                SpendingVM.results[currWeek-1].WeeklyNet += test.Price
                                SpendingVM.results[currWeek-1].Entries.remove(at:SpendingVM.results[currWeek-1].Entries.firstIndex(of: test)!)
                                SpendingVM.objectWillChange.send()
                                SpendingVM.writeToJson()
                                print(SpendingVM.results[currWeek-1].Entries.count)
                            }label: {
                                Image(systemName: "x.circle.fill")
                                    .padding()
                            }
                        }
                        
                    }
                    
                }
                    }.padding()
            }.frame(alignment:.center)
        
            NavigationLink{

                AddSpendingView().environmentObject(SpendingVM).environmentObject(weeklyNets)
            
        } label: {
            ZStack{
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color.white)
                    .shadow(radius: 1)
                    .frame(width: 200, height: 40, alignment: .center)
                
                Text("Add Spending")
                    .padding()
                    .frame(alignment: .leading)
                Spacer()
            }.frame(width: 200, height: 20, alignment: .center).padding()
            
        }.padding(.bottom)
        }.navigationBarHidden(true)
        }
    }
}
        
    



struct SpendingTab_Previews: PreviewProvider {
    static var previews: some View {
        SpendingTab().environmentObject(CurrentDate())
            .environmentObject(SpendingViewModel())
            .environmentObject(WeeklyNetTotal())
    }
}

