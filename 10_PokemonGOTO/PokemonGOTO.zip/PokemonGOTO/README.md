
# PokemonGOTO

A Pokemon game that incentivises users to engage in their community and be more active while having fun!
## Features

- Pokedex
- Map
- PC

## Roadmap

- Pokemon on map

- Cache API data

- Vibes

- Battles

