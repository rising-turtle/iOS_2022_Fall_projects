//
//  Location.swift
//  WolverineSport
//
//  Created by Christopher Gerello on 12/7/22.
//

import Foundation
struct Location : Identifiable, Decodable{
    var id = 0
    var name = ""
    var latitude = 0.0
    var longitude = 0.0
}

