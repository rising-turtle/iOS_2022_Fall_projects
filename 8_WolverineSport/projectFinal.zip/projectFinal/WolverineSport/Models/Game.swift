
//
//  Game.swift
//  WolverineSport
//
//  Created by Christopher Gerello on 12/7/22.
//

import Foundation
struct Game : Identifiable, Decodable{
    var id = 0 // UUID?
    var date : Double = 0.0 // Date
    var location = Location()
    var awayTeam = ""
    var homeTeam = ""
}

