//
//  JoinView.swift
//  WolverineSport
//
//  Created by Christopher Gerello on 12/8/22.
//

import SwiftUI

struct JoinView: View {
    @State var team = ""
    @State var name = ""
    var body: some View {
        Form{
            Section(header: Text("Enter your Team Name to Join:")){
                TextField("Tigers", text: $team)
            }
            Section(header: Text("Enter your Name:")){
                TextField("John Smith", text: $name)
            }
            Button{
            } label: {
                Text("Join Team")
            }
        }
        .navigationTitle("Join Team")
}
    }

struct JoinView_Previews: PreviewProvider {
    static var previews: some View {
        JoinView()
    }
}
