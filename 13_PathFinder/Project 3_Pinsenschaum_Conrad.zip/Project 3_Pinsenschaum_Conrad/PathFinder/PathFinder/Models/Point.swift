//
//  Point.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/15/22.
//

import Foundation

class Point : Identifiable, Decodable {
    var id: Int = -1
    var locationIds: [Int] = [Int]()
    var connectionIds: [Int] = [Int]()
    var lat: Double = 0.0
    var lon: Double = 0.0
    
    enum CodingKeys: String, CodingKey {
        case id, locationIds, connectionIds, lat, lon
    }
    
    var visible: Bool = false
    var isActive: Bool = true
}

class DPoint {
    var parentId: Int? = nil
    var curWeight: Double = -1
    var point: Point = Point()
    
    init(_ curWeight: Double, _ point: Point) {
        self.curWeight = curWeight
        self.point = point
    }
}
