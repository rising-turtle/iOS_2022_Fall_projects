//
//  Point.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/10/22.
//

import Foundation

struct Json_Data : Identifiable, Decodable {
    var id: UUID = UUID()
    var locations: [Location] = [Location]()
    var points: [Point] = [Point]()
    
    enum CodingKeys: String, CodingKey {
        case locations, points
    }
}

class Location : Identifiable, Decodable {
    var id: Int = -1
    var name: String = ""
    var lat: Double = 0.0
    var lon: Double = 0.0
    var subpoints: [Int] = [Int]()
    
    enum CodingKeys: String, CodingKey {
        case id, name, lat, lon, subpoints
    }
    
    var visible: Bool = true
    var pointsVisible: Bool = false
    var isActive: Bool = true
}
