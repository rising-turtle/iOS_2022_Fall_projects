//
//  Route.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/15/22.
//

import Foundation
import RealmSwift

// Realm Database Route
class RealmRoute : Object, Identifiable {
    @Persisted(primaryKey: true) var _id: ObjectId
    var id = UUID()
    @Persisted var name: String = ""
    @Persisted var startPointId: Int = -1
    @Persisted var endPointId: Int = -1
    @Persisted var distance_miles: Double = -1.0
    @Persisted var pointIds: String = ""
    @Persisted var wayPointIds: String = ""
    
    // computed distance conversions
    var distance_kilometers: Double {
        if distance_miles == -1.0 {
            return -1.0
        }
        return distance_miles * 1.609344
    }
    var distance_nauticalMiles: Double {
        if distance_miles == -1.0 {
            return -1.0
        }
        return distance_miles * 0.8684
    }
    var distance_feet: Double {
        if distance_miles == -1.0 {
            return -1.0
        }
        return distance_miles * 5280
    }
    
    // distance strings
    var distanceString_miles: String {
        return String(format: "%.2f miles", distance_miles)
    }
    var distanceString_kilometers: String {
        return String(format: "%.2f kilometers", distance_kilometers)
    }
    var distanceString_nauticalMiles: String {
        return String(format: "%.2f nautical miles", distance_nauticalMiles)
    }
    var distanceString_feet: String {
        return String(format: "%.2f feet", distance_feet)
    }

    convenience init(_ name: String, _ startPointId: Int, _ endPointId: Int, _ distance_miles: Double, _ pointIds: String, _ wayPointIds: String) {
        self.init()
        self.name = name
        self.startPointId = startPointId
        self.endPointId = endPointId
        self.distance_miles = distance_miles
        self.pointIds = pointIds
        self.wayPointIds = wayPointIds
    }
    
    convenience init(_ other: RealmRoute) {
        self.init()
        self.id = other.id
        self.name = other.name
        self.startPointId = other.startPointId
        self.endPointId = other.endPointId
        self.distance_miles = other.distance_miles
        self.pointIds = other.pointIds
        self.wayPointIds = other.wayPointIds
    }
    
    func setPointIds(_ ids: [Int]) {
        pointIds = RealmRoute.convertIdsToString(ids)
    }
    
    func getPointIds() -> [Int] {
        return RealmRoute.convertStringToIds(pointIds)
    }
    
    func setWayPointIds(_ ids: [Int]) {
        wayPointIds = RealmRoute.convertIdsToString(ids)
    }
    
    func getWayPointIds() -> [Int] {
        return RealmRoute.convertStringToIds(wayPointIds)
    }
    
    static func convertIdsToString(_ ids: [Int]) -> String {
        return ",".join(array: ids)
    }
    
    static func convertStringToIds(_ stringIds: String) -> [Int] {
        let a = stringIds.components(separatedBy: ",")
        var retArray = [Int]()
        for i in a {
            retArray.append(Int(i) ?? -1)
        }
        return retArray
    }
}

extension String {
    func join(array: [Int]) -> String {
        var str:String = ""
        for (index, item) in array.enumerated() {
            str += "\(item)"
            if index < array.count-1 {
                str += self
            }
        }
        return str
    }
}
