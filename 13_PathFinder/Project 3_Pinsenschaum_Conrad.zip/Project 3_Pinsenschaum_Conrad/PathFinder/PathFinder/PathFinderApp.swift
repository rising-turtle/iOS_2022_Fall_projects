//
//  PathFinderApp.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/8/22.
//
//  PathFinder; Levi Conrad and R. Todd Pinsenschaum II
//

import SwiftUI

@main
struct PathFinderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
