//
//  HistoryView.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/9/22.
//

import SwiftUI

struct HistoryView: View {
    @ObservedObject var LM = LocationModel.shared
    @ObservedObject var CM = Calculator.shared
    
    var body: some View {
        VStack {
//            Text("Route History")
//                .font(.largeTitle)
//            Divider()

            NavigationView {
                ScrollView {
                    ForEach(0..<CM.routes.count, id: \.self) { i in
                        Divider()
                        
                        if let route = CM.routes[i], let sp = LM.points[route.startPointId], let ep = LM.points[route.endPointId] {
                            NavigationLink {
                                HistoryMapView(route: RealmRoute(route))
                            } label: {
                                VStack(alignment: .leading) {
                                    HStack {
                                        // route name
                                        Text("\(route.name)")
                                            .font(.title)
                                        Spacer()
                                        Button {
                                            // delete a recorded route
                                            CM.deleteRoute(route)
                                        } label: {
                                            Image(systemName: "xmark.circle.fill")
                                                .foregroundColor(.red)
                                                .scaleEffect(1.5)
                                        }
                                    }
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 5)
                                    
                                    HStack {
                                        pointView(title: "Starting Point", point: sp)
                                        pointView(title: "Ending Point", point: ep)
                                    }
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 5)
                                    
                                    HStack {
                                        Text("Distance: ")
                                            .bold()
                                        Text("\(route.distanceString_feet)")
                                    }
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 5)
                                }
                            }
                            .foregroundColor(.black)
                        }
                        //Divider()
                    }
                    .navigationBarTitle("Route History")
                }
            }
        }
    }
        
    func pointView(title: String, point: Point) -> some View {
        Group {
            // point
            VStack (alignment: .leading, spacing: 5) {
                Text("\(title): ")
                    .bold()
                
                // lat, lon, x
                HStack {
                    VStack (alignment: .leading) {
                        HStack {
                            // titles
                            VStack (alignment: .leading) {
                                Text("id: ")
                                    .foregroundColor(.black)
                                    .font(.caption)
                                Text("lat: ")
                                    .foregroundColor(.black)
                                    .font(.caption)
                                Text("lon: ")
                                    .foregroundColor(.black)
                                    .font(.caption)
                            }
                            .padding(.leading, 10)
                            
                            // values
                            VStack (alignment: .leading) {
                                Text(" \(point.id)")
                                    .foregroundColor(.green)
                                    .font(.caption)
                                let lat = point.lat < 0 ? "\(point.lat)" : " \(point.lat)"
                                Text(lat)
                                    .foregroundColor(.green)
                                    .font(.caption)
                                let lon = point.lon < 0 ? "\(point.lon)" : " \(point.lon)"
                                Text(lon)
                                    .foregroundColor(.green)
                                    .font(.caption)
                            }
                        }
                    }
                    Spacer()
                }
            }
        }
    }
}

struct HistoryView_Previews: PreviewProvider {
    static var previews: some View {
        HistoryView()
    }
}
