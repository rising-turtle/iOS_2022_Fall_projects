//
//  DrawerPointView.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 12/3/22.
//

import SwiftUI

struct DrawerPointView: View {
    
    @ObservedObject var CM = Calculator.shared
    
    var title: String
    var point: Point?
    
    var body: some View {
        VStack (alignment: .leading, spacing: 5) {
            HStack {
                Text(title)
                    .bold()
                Spacer()
                Button {
                    if let point = point {
                        CM.waypointsRemove(point)
                    }
                } label: {
                    if point != nil {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.red)
                    } else {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.gray)
                    }
                }
            }
            
            // lat, lon, x
            if let point = point {
                HStack {
                    HStack {
                        Text("id:")
                            .foregroundColor(.black)
                        Text("\(point.id)")
                            .foregroundColor(.green)
                    }
                    .padding(.trailing, 5)
                    
                    HStack {
                        Text("lat:")
                            .foregroundColor(.black)
                        Text("\(point.lat)")
                            .foregroundColor(.green)
                    }
                    .padding(.trailing, 5)
                    
                    HStack {
                        Text("lon:")
                            .foregroundColor(.black)
                        Text("\(point.lon)")
                            .foregroundColor(.green)
                    }
                    .padding(.trailing, 5)
                    Spacer()
                }
                .font(.caption)
            } else {
                Text("none")
                    .font(.caption)
            }
        }
    }
}

