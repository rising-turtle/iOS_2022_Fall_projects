//
//  DrawerView.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/14/22.
//

import SwiftUI

struct DrawerView: View {
    
    @ObservedObject var LM = LocationModel.shared
    @ObservedObject var CM = Calculator.shared
    
    var body: some View {
        VStack {
            HStack {
                Spacer()
                calculateButtonView()
            }
            
            VStack () {
                topNotchView()
                
                // Settings controls
                HStack {
                    // clear button
                    Button {
                        if CM.waypoints.count > 0 {
                            CM.waypoints.removeAll()
                            CM.curRoute = nil
                        }
                    } label: {
                        ZStack(alignment: .leading) {
                            //invisible
                            RoundedRectangle(cornerRadius: 20)
                                .frame(width: 120, height: 30)
                                .foregroundColor(.white)
                            
                            ZStack {
                                if CM.waypoints.count <= 0 {
                                    RoundedRectangle(cornerRadius: 20)
                                        .frame(width: 60, height: 30)
                                        .foregroundColor(.gray)
                                } else {
                                    RoundedRectangle(cornerRadius: 20)
                                        .frame(width: 60, height: 30)
                                        .foregroundColor(.red)
                                }
                                
                                Text("clear")
                                    .bold()
                                    .foregroundColor(.white)
                            }
                        }
                        .padding(.top, 20)
                    }
                    
                    Spacer()
                    Text("Route")
                        .multilineTextAlignment(.center)
                        .font(.title)
                        .padding(.all, 10)
                    Spacer()
                    
                    ZStack {
                        //invisible
                        RoundedRectangle(cornerRadius: 20)
                            .frame(width: 120, height: 30)
                            .foregroundColor(.white)
                        
                        ZStack {
                            if let route = CM.curRoute {
                                RoundedRectangle(cornerRadius: 20)
                                    .frame(width: 120, height: 30)
                                    .foregroundColor(.green)
                                Text("\(route.distanceString_feet)")
                                    .foregroundColor(.white)
                            } else {
                                RoundedRectangle(cornerRadius: 20)
                                    .frame(width: 120, height: 30)
                                    .foregroundColor(.gray)
                                Text("-")
                                    .foregroundColor(.white)
                            }
                        }
                    }
                    .padding(.top, 20)
                }
                
                // points
                
                HStack (alignment: .top) {
                    ScrollView() {
                        
                        if CM.waypoints.count >= 1 {
                            // first point
                            Divider()
                            DrawerPointView(title: "Starting Point: ", point: CM.waypoints.first)
                                .padding(.bottom, 5)
                            
                            if CM.waypoints.count == 1 {
                                // only one point so fill in the end point
                                Divider()
                                DrawerPointView(title: "Ending Point: ", point: nil)
                                    .padding(.top, 5)
                                    .padding(.bottom, 5)
                            } else {
                                ForEach(1..<CM.waypoints.count, id: \.self) { i in
                                    
                                    if i == CM.waypoints.count-1 {
                                        Divider()
                                        DrawerPointView(title: "Ending Point: ", point: CM.waypoints[i])
                                            .padding(.top, 5)
                                            .padding(.bottom, 20)
                                    } else {
                                        Divider()
                                        DrawerPointView(title: "Stop \(i): ", point: CM.waypoints[i])
                                            .padding(.top, 5)
                                            .padding(.bottom, 5)
                                    }
                                }
                            }
                        } else {
                            // no waypoints
                            Divider()
                            DrawerPointView(title: "Starting Point: ", point: nil)
                                .padding(.bottom, 5)
                            Divider()
                            DrawerPointView(title: "Ending Point: ", point: nil)
                                .padding(.top, 5)
                        }
                    }
                }
                Spacer()
            }
            .padding(.top, 8)
            .padding(.horizontal, 20)
            .frame(maxWidth: .infinity, maxHeight: 260)
            .background(.white)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .shadow(radius: 5)
        }
    }

    func topNotchView() -> some View {
        Group {
            Rectangle()
                .frame(width: 30, height: 3)
                .cornerRadius(3)
                .foregroundColor(.gray)
        }
    }
    
    func calculateButtonView() -> some View {
        Group {
            HStack {
                // Error View
                if let route_error = CM.errorName {
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .frame(width: 150, height: 40)
                            .foregroundColor(.red)
                        Text(route_error)
                            .foregroundColor(.white)
                    }
                }
                
                // Calculate Button
                if CM.canCalculate {
                    Button {
                        // calculate and display fastest route
                        CM.calculateRoute()
                    } label: {
                        ZStack {
                            Circle()
                                .frame(width: 50, height: 50)
                                .foregroundColor(.green)
                            Image(systemName: "location.fill")
                                .foregroundColor(.white)
                                .scaleEffect(1.5)
                        }
                    }
                    .padding(.vertical, 8)
                    .padding(.horizontal, 20)
                } else {
                    Button {
                        //do nothing
                    } label: {
                        ZStack {
                            Circle()
                                .frame(width: 50, height: 50)
                                .foregroundColor(.gray)
                            Image(systemName: "location.fill")
                                .foregroundColor(.white)
                                .scaleEffect(1.5)
                        }
                    }
                    .padding(.vertical, 8)
                    .padding(.horizontal, 20)
                }
            }
        }
    }
}

struct DrawerView_Previews: PreviewProvider {
    static var previews: some View {
        DrawerView()
    }
}
