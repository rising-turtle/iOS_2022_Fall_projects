//
//  HistoryMapView.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/15/22.
//

import SwiftUI
import MapKit

struct MyHMapView : UIViewRepresentable {
    
    @ObservedObject var LM = LocationModel.shared
    @ObservedObject var CM = Calculator.shared

    var startingLat: Double = 41.155386
    var startingLon: Double = -80.079882
    var startingName: String = "Grove City College"
    
    var route: RealmRoute
    
    var startingRegion : MKCoordinateRegion {
        return MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: startingLat, longitude: startingLon), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
    }
    
    var routePoints: [MKPointAnnotation] {
        var locs = [MKPointAnnotation]()
        let pids: [Int] = route.getWayPointIds()
        
        for pid in pids {
            if let point = LM.points[pid] {
                let p = MKPointAnnotation()
                p.coordinate = CLLocationCoordinate2D(latitude: point.lat, longitude: point.lon)
                p.title = "\(point.id)"
                locs.append(p)
            }
        }
        
        return locs
    }
    
    // === Methods ===
    // create
    func makeUIView(context: Context) -> MKMapView {
        let mv = MKMapView()
        mv.delegate = context.coordinator
        
        // region
        mv.setRegion(startingRegion, animated: true)
        
        // map settings
        mv.mapType = .satellite
        
        return mv
    }
    
    // update
    func updateUIView(_ uiView: MKMapView, context: Context) {
        // annotations
        uiView.removeAnnotations(uiView.annotations)
        uiView.addAnnotations(routePoints)
        
        // draw route lines
        var lineCoordinates = [CLLocationCoordinate2D]()
        let pids: [Int] = route.getPointIds()
        for pid in pids {
            if let point = LM.points[pid] {
                lineCoordinates.append(CLLocationCoordinate2D(latitude: point.lat, longitude: point.lon))
            }
            
        }
        
        let polyline = MKPolyline(coordinates: lineCoordinates, count: lineCoordinates.count)
        uiView.addOverlay(polyline)
    }
    
    // tear down
    static func dismantleUIView(_ uiView: MKMapView, coordinator: ()) {
        
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(map: self)
    }
    
    // === Delegate ===
    class Coordinator : NSObject, MKMapViewDelegate {
        
        var map : MyHMapView
        
        init(map: MyHMapView) {
            self.map = map
        }
        
        // customize points
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "myPoint")
            
            // annotation display
            annotationView.displayPriority = .required
            annotationView.titleVisibility = .visible
            
            return annotationView
        }
        
        // line between points
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let routePolyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: routePolyline)
                renderer.strokeColor = UIColor.systemBlue
                renderer.lineWidth = 5
                return renderer
            }
            return MKOverlayRenderer()
        }
    }
}

// History Map View
struct HistoryMapView: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    @ObservedObject var CM = Calculator.shared
    
    var route: RealmRoute
    @State var name = ""
    
    var body: some View {
        VStack(alignment: .leading) {
            MyHMapView(route: route)
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarBackButtonHidden(true)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        btnBack
                    }
                    ToolbarItem(placement: .principal) {
                        nameEdit
                    }
                }
            
        }
    }
    
    var btnBack : some View {
        Button {
            self.mode.wrappedValue.dismiss()
        } label: {
            Image(systemName: "arrow.left")
                .foregroundColor(.blue)
        }
    }
    
    var nameEdit : some View {
        Group {
            if let route = route {
                TextField("\(route.name)", text: $name)
                    .onSubmit {
                        // change name in realm db
                        CM.changeRouteName(route, name)
                    }
                    .font(.title)
            }
        }
    }
}
