//
//  MapView.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/9/22.
//

import SwiftUI
import MapKit

struct MyView : UIViewRepresentable {
    
    @ObservedObject var LM = LocationModel.shared
    @ObservedObject var CM = Calculator.shared

    var startingLat: Double = 41.155386
    var startingLon: Double = -80.079882
    var startingName: String = "Grove City College"
    
    var startingRegion : MKCoordinateRegion {
        return MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: startingLat, longitude: startingLon), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
    }
    
    var startingPOI: MKPointAnnotation {
        let loc = MKPointAnnotation()
        loc.coordinate = CLLocationCoordinate2D(latitude: startingRegion.center.latitude, longitude: startingRegion.center.longitude)
        loc.title = startingName
        
        return loc
    }
    
    var locations: [MKPointAnnotation] {
        var locs = [MKPointAnnotation]()
        
        // locations
        for key in LM.locations.keys {
            if let loc: Location = LM.locations[key] {
                if loc.visible {
                    let mapLoc = MKPointAnnotation()
                    mapLoc.coordinate = CLLocationCoordinate2D(latitude: loc.lat, longitude: loc.lon)
                    mapLoc.title = loc.name
                    
                    locs.append(mapLoc)
                }
            }
        }
        
        // points
        for key in LM.points.keys {
            if let point: Point = LM.points[key] {
                if point.visible {
                    let mapPoint = MKPointAnnotation()
                    mapPoint.coordinate = CLLocationCoordinate2D(latitude: point.lat, longitude: point.lon)
                    mapPoint.title = "\(point.id)"
                    locs.append(mapPoint)
                }
            }
        }
        
        return locs
    }
    
    // === Methods ===
    // create
    func makeUIView(context: Context) -> MKMapView {
        let mv = MKMapView()
        mv.delegate = context.coordinator
        
        // region
        mv.setRegion(startingRegion, animated: true)
        
        // map settings
        mv.mapType = .satellite
        
        // map zoom limits
        mv.cameraZoomRange = MKMapView.CameraZoomRange(
                    minCenterCoordinateDistance: 150, // Minimum zoom value
                    maxCenterCoordinateDistance: 10000) // Max zoom value
        
//        mv.removeAnnotations(mv.annotations)
//        mv.addAnnotations(locations)
        
        return mv
    }
    
    // update
    func updateUIView(_ uiView: MKMapView, context: Context) {
        // annotations
        uiView.removeAnnotations(uiView.annotations)
        uiView.addAnnotations(locations)
        
        // draw route lines
        if let route = CM.curRoute {
            var lineCoordinates = [CLLocationCoordinate2D]()
            let pids: [Int] = route.getPointIds()
            for pid in pids {
                if let point = LM.points[pid] {
                    lineCoordinates.append(CLLocationCoordinate2D(latitude: point.lat, longitude: point.lon))
                }
            }
            
            let polyline = MKPolyline(coordinates: lineCoordinates, count: lineCoordinates.count)
            uiView.addOverlay(polyline)
        }
        else {
            // remove route lines
            uiView.removeOverlays(uiView.overlays)
        }
    }
    
    // tear down
    static func dismantleUIView(_ uiView: MKMapView, coordinator: ()) {
        
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(map: self)
    }
    
    // === Delegate ===
    class Coordinator : NSObject, MKMapViewDelegate {
        
        @ObservedObject var LM = LocationModel.shared
        @ObservedObject var CM = Calculator.shared
        
        var map : MyView
        
        init(map: MyView) {
            self.map = map
        }
        
        // customize points
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "myPoint")
            
            var location : Location?
            var point : Point?
            
            // determine if location was clicked
            for loc in LM.locations.values {
                if loc.name == annotationView.annotation?.title {
                    location = loc
                    break
                }
            }
            
            // determine if point was clicked
            for p in LM.points.values {
                if p.id.codingKey.stringValue == annotationView.annotation?.title {
                    point = p
                    break
                }
            }
            
            // check if location or point was clicked
            if let loc = location {
                // right callout : show or hide points
                let button = UIButton(frame: CGRect(x: 0, y: 0, width: 27, height: 25))
                button.setImage(UIImage(systemName: "eye.circle"), for: .normal)
                button.contentVerticalAlignment = .fill
                button.contentHorizontalAlignment = .fill
                annotationView.rightCalloutAccessoryView = button
                
                // left callout : enable or disable points
                let b = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
                b.contentVerticalAlignment = .fill
                b.contentHorizontalAlignment = .fill
                b.setImage(UIImage(systemName: "location.slash"), for: .normal)
                annotationView.leftCalloutAccessoryView = b
                
                // color
                if loc.isActive {
                    annotationView.markerTintColor = .red
                } else {
                    annotationView.markerTintColor = .black
                }
            } else if let p = point {
                // right callout : add as starting or ending point
                annotationView.rightCalloutAccessoryView = UIButton(type: .contactAdd)
                
                // left callout : enable or disable point
                let b = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
                b.contentVerticalAlignment = .fill
                b.contentHorizontalAlignment = .fill
                b.setImage(UIImage(systemName: "location.slash"), for: .normal)
                annotationView.leftCalloutAccessoryView = b
                
                // color
                if p.isActive {
                    annotationView.markerTintColor = .green
                    
                    // check if starting point
                    if CM.waypointsContains(p) {
                        annotationView.markerTintColor = .blue
                    }
                }
                else {
                    annotationView.markerTintColor = .gray
                }
            }
            
            // annotation display
            annotationView.displayPriority = .required
            annotationView.titleVisibility = .visible
            
            // callout
            annotationView.canShowCallout = true
                        
            return annotationView
        }
        
        // how to respond
        func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
            
            var location : Location?
            var point : Point?
            
            // determine if location was clicked
            for loc in LM.locations.values {
                if loc.name == view.annotation?.title {
                    location = loc
                    break
                }
            }
            
            // determine if point was clicked
            for p in LM.points.values {
                if p.id.codingKey.stringValue == view.annotation?.title {
                    point = p
                    break
                }
            }
            
            // check if location or point was clicked
            if let loc = location {
                // clicked a location
                if view.rightCalloutAccessoryView == control {
                    // right accessory : show or hide points
                    loc.pointsVisible.toggle()
                    
                    for pointId in loc.subpoints {
                        // points shown or not
                        if let point = LM.points[pointId] {
                            if point.visible {
                                if !shouldBeOn(point: point) {
                                    point.visible.toggle()
                                    mapView.removeAnnotation(getPointRemove(mapView, pointId: pointId))
                                }
                            } else {
                                if shouldBeOn(point: point) {
                                    point.visible.toggle()
                                    mapView.addAnnotation(getPointAdd(pointId: pointId))
                                }
                            }
                        }
                    }
                } else {
                    // reset route
                    CM.curRoute = nil
                    
                    // left accessory : enable or disable points
                    toggleLocation(mapView, location: loc)
                    
                    for pointId in loc.subpoints {
                        if let point = LM.points[pointId] {
                            if loc.isActive {
                                if point.visible {
                                    setPointActive(mapView, point: point)
                                } else {
                                    point.isActive = true
                                }
                            } else {
                                if point.visible {
                                    setPointInactive(mapView, point: point)
                                } else {
                                    point.isActive = false
                                }
                            }
                        }
                    }
                }
            } else if let p = point {
                if view.rightCalloutAccessoryView == control {
                    // right accessory : add to waypoints
                    CM.waypointsAdd(p)
                    p.isActive = true
                    
                    // redraw the specific point
//                    mapView.removeAnnotation(getPointRemove(mapView, pointId: p.id))
//                    mapView.addAnnotation(getPointAdd(pointId: p.id))
                } else {
                    // reset route
                    CM.curRoute = nil
                    
                    // left accessory : enable or disable point
                    if p.isActive {
                        setPointInactive(mapView, point: p)
                    } else {
                        setPointActive(mapView, point: p)
                    }
                }
            }
        }
        
        // line between points
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let routePolyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: routePolyline)
                renderer.strokeColor = UIColor.systemBlue
                renderer.lineWidth = 5
                return renderer
            }
            return MKOverlayRenderer()
        }
        
        // === Location Methods ===
        func toggleLocation(_ mapView: MKMapView, location: Location) {
            location.isActive.toggle()
            
            // redraw the specific point
            mapView.removeAnnotation(getLocationRemove(mapView, locationName: location.name))
            mapView.addAnnotation(getLocationAdd(locationId: location.id))
        }
        
        func getLocationAdd(locationId: Int) -> MKPointAnnotation {
            let loc = MKPointAnnotation()
            
            if let location: Location = LM.locations[locationId] {
                loc.coordinate = CLLocationCoordinate2D(latitude: location.lat, longitude: location.lon)
                loc.title = "\(location.name)"
            }
            return loc
        }
        
        func getLocationRemove(_ mapView: MKMapView, locationName: String) -> MKAnnotation {
            let loc = MKPointAnnotation()
            
            for location in mapView.annotations {
                if location.title == locationName {
                    return location
                }
            }
            return loc
        }
        
        // === Point Methods ===
        func setPointActive(_ mapView: MKMapView, point: Point) {
            point.isActive = true
            
            // redraw the specific point
            mapView.removeAnnotation(getPointRemove(mapView, pointId: point.id))
            mapView.addAnnotation(getPointAdd(pointId: point.id))
        }
        
        func setPointInactive(_ mapView: MKMapView, point: Point) {
            point.isActive = false
            CM.waypointsRemove(point)
            
            // redraw the specific point
            mapView.removeAnnotation(getPointRemove(mapView, pointId: point.id))
            mapView.addAnnotation(getPointAdd(pointId: point.id))
        }
        
        func getPointAdd(pointId: Int) -> MKPointAnnotation {
            let loc = MKPointAnnotation()
            
            if let point: Point = LM.points[pointId] {
                loc.coordinate = CLLocationCoordinate2D(latitude: point.lat, longitude: point.lon)
                loc.title = "\(point.id)"
            }
            return loc
        }
        
        func getPointRemove(_ mapView: MKMapView, pointId: Int) -> MKAnnotation {
            let loc = MKPointAnnotation()
            
            for point in mapView.annotations {
                if point.title == pointId.codingKey.stringValue {
                    return point
                }
            }
            return loc
        }
        
        func shouldBeOn(point: Point) -> Bool {
            for locID in point.locationIds {
                if let loc = LM.locations[locID] {
                    if loc.pointsVisible {
                        return true
                    }
                }
            }
            return false
        }
    }
}



enum DraggingState {
    case dragging, open, closed
}

// Map View
struct MapView: View {
    
    @ObservedObject var LM = LocationModel.shared
    @ObservedObject var CM = Calculator.shared
    
    @State private var drawerDragging = DraggingState.closed
    @State var offset: CGFloat = 0
    @State var lastOffset: CGFloat = 0
    @GestureState var gestureOffset: CGFloat = 0
    @State var heightS = 0.0
    
    var fixedOffset: CGFloat {
        let maxHeight = heightS - 100
        if offset <= -(maxHeight / 3.2) {
            return -(maxHeight / 3.2)
        }
        return offset
    }
    
    var body: some View {
        ZStack {
            MyView()
                //.ignoresSafeArea()
            
            GeometryReader { reader -> AnyView in
                let height = reader.frame(in: .global).height
                heightS = height
                
                return AnyView(
                    ZStack {
                        DrawerView()
                    }
                    .offset(y: height - 100)
                    .offset(y: fixedOffset)
                    .gesture(DragGesture().updating($gestureOffset, body: { value, out, _ in
                        out = value.translation.height
                        onChange(max: -((height - 100) / 3.2))
                        drawerDragging = .dragging
                    }).onEnded({ value in
                        
                        let maxHeight = height - 100
                        withAnimation {
                            // up down or mid states
                            if -offset > 75 && -offset < maxHeight/3.2 {
                                // mid
                                offset = -(maxHeight / 3.2)
                                drawerDragging = .open
                            } else if -offset > maxHeight / 3.2 {
                                // up
                                //offset = -maxHeight
                                offset = -(maxHeight / 3.2)
                                drawerDragging = .open
                            } else {
                                // down
                                offset = 0
                                drawerDragging = .closed
                            }
                        }
                        
                        // Storing Last Offset
                        lastOffset = offset
                        
                    }))
                )
            }
            //.ignoresSafeArea(.all, edges: .vertical)
        }
    }

    
    func onChange(max: Double) {
        DispatchQueue.main.async {
            self.offset = gestureOffset + lastOffset
        }
    }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
    }
}

