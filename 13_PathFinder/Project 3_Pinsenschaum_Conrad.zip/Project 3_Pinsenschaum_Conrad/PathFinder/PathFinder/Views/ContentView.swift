//
//  ContentView.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/8/22.
//

import SwiftUI

struct ContentView: View {

    var body: some View {
        TabView() {
            MapView().tabItem {
                // how the tab 1 looks
                VStack {
                    Image(systemName: "map")
                    Text("Map")
                }
            }
            
            HistoryView().tabItem {
                // how the tab 2 looks
                VStack {
                    Image(systemName: "book")
                    Text("History")
                }
            }
        }
        .onAppear {
            UITabBar.appearance().backgroundColor = UIColor(.white)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
