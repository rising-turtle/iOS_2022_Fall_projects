//
//  Calculator.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/14/22.
//

import Foundation
import RealmSwift

class Calculator : ObservableObject {
    
    @Published var waypoints: [Point] = [Point]()
    @Published var routes : [RealmRoute]
    @Published var curRoute : RealmRoute?
    @Published var errorName : String? {
        didSet {
            if errorName != nil {
                numErrors += 1
                let secondsToDelay = 3.0
                DispatchQueue.main.asyncAfter(deadline: .now() + secondsToDelay) {
                    self.numErrors -= 1
                    if self.numErrors <= 0 {
                        self.numErrors = 0
                        self.errorName = nil
                    }
                }
            }
        }
    }
    
    var numErrors: Int = 0
    
    var canCalculate: Bool {
        return waypoints.count >= 2
    }
  
    // singleton
    static let shared: Calculator = {
        return Calculator()
    }()
    
    init() {
        /// TODO: get rid of this
//        let realm = try! Realm()
//        try! realm.write {
//            realm.deleteAll()
//        }
        
        routes = [RealmRoute]()
        updateRoutes()
    }
    
    
    // === Route Functions ===
    
    // calculate route method
    func calculateRoute() {
        if canCalculate {
            if let sp = waypoints.first, let ep = waypoints.last, waypoints.count >= 2 {
                // calculate shortest route
                var dist = 0.0
                var pids_ints = [Int]()
                var wpids_ints = [Int]()
                
                for i in 0..<waypoints.count-1 {
                    let p1 = waypoints[i]
                    let p2 = waypoints[i+1]
                    
                    // find fastest route
                    let points_dist: ([Int]?, Double) = findShortestPath(p1: p1, p2: p2)
                    errorName = nil
                    if let foundRoute = points_dist.0 {
                        dist += points_dist.1
                        
                        // append all points except the last one
                        for i in 0..<foundRoute.count-1 {
                            pids_ints.append(foundRoute[i])
                        }

                        wpids_ints.append(p1.id)
                    } else {
                        // no route found
                        errorName = "no route found"
                        return
                    }
                }
                
                // add the last point
                pids_ints.append(ep.id)
                wpids_ints.append(ep.id)
                
                let pids = RealmRoute.convertIdsToString(pids_ints)
                let wpids = RealmRoute.convertIdsToString(wpids_ints)
                
                // add new route to realm database
                let realm = try! Realm()
                
                let route_realm: RealmRoute = RealmRoute("\(sp.id) to \(ep.id)", sp.id, ep.id, dist, pids, wpids)
                try! realm.write {
                    realm.add(route_realm)
                }
                
                curRoute = route_realm
                updateRoutes()
            }
        }
    }
    
    func updateRoutes() {
        var rArray = [RealmRoute]()
        let realm = try! Realm()
        for r in realm.objects(RealmRoute.self) {
            if !r.isInvalidated {
                rArray.append(r)
            }
        }
        
        self.routes = rArray
    }
    
    func deleteRoute(_ route: RealmRoute) {
        if let cr = curRoute {
            if cr == route {
                curRoute = nil
            }
        }

        let realm = try! Realm()
        if !route.isInvalidated {
            try! realm.write {
                realm.delete(route)
            }
        }
        
        updateRoutes()
    }
    
    func changeRouteName(_ route: RealmRoute, _ newName: String) {
        // find actual route
        var foundRoute: RealmRoute? = nil
        for r in routes {
            if route.id == r.id {
                foundRoute = r
                break
            }
        }
        
        if let fr = foundRoute {
            if let cr = curRoute {
                if cr == fr {
                    curRoute = nil
                }
            }
            let realm = try! Realm()
            if !fr.isInvalidated {
                try! realm.write {
                    fr.name = newName
                }
            }
        }
        
        updateRoutes()
    }
    
    
    // --- Helper Functions ---
    
    func waypointsContains(_ point: Point) -> Bool {
        for wp in waypoints {
            if wp.id == point.id {
                return true
            }
        }
        return false
    }
    
    func waypointsIndex(_ point: Point) -> Int {
        var i = 0
        for wp in waypoints {
            if wp.id == point.id {
                return i
            }
            i+=1
        }
        return -1
    }
    
    func waypointsAdd(_ point: Point) {
        if !waypointsContains(point) {
            waypoints.append(point)
            curRoute = nil
        }
    }
    
    func waypointsRemove(_ point: Point) {
        let i = waypointsIndex(point)
        if i >= 0 {
            waypoints.remove(at: waypointsIndex(point))
            curRoute = nil
        }
    }

    // convert decimal degrees to radians
    func deg2rad(_ deg: Double) -> Double {
        return deg * Double.pi / 180
    }

    // convert radians to decimal degrees
    func rad2deg(_ rad: Double) -> Double {
        return rad * 180.0 / Double.pi
    }

    // calculate distance between two lat/lon points
    func distance(lat1: Double, lon1: Double, lat2: Double, lon2: Double) -> Double {
        let theta = lon1 - lon2
        var dist = sin(deg2rad(lat1)) * sin(deg2rad(lat2)) + cos(deg2rad(lat1)) * cos(deg2rad(lat2)) * cos(deg2rad(theta))
        dist = acos(dist)
        dist = rad2deg(dist)
        dist = dist * 60 * 1.1515

        return dist
    }
    
    
    // === Find Shortest Path ===
    func findShortestPath(p1: Point, p2: Point) -> ([Int]?, Double) {
        
        let pWeights = Dijkstra(s: p1)
        if let endDPoint = pWeights[p2.id] {
            // distance
            let dist = endDPoint.curWeight
            
            // get route
            if let route = extractRoute(pWeights: pWeights, p1: p1, p2: endDPoint) {
                print(route)
                return (route, dist)
            } else {
                // no route possible
                return (nil, -1)
            }
        }
        print("Something went wrong")
        
        // default route
        return ([p1.id, p2.id], distance(lat1: p1.lat, lon1: p1.lon, lat2: p2.lat, lon2: p2.lon))
    }
    
    func extractRoute(pWeights: [Int:DPoint], p1: Point, p2: DPoint) -> [Int]? {
        var retArray: [Int] = [p2.point.id]
        var curP: DPoint = p2
        
        while curP.point.id != p1.id {
            if let parentId = curP.parentId {
                if let newP = pWeights[parentId] {
                    curP = newP
                    retArray.append(curP.point.id)
                }
            } else {
                return nil
            }
        }
        retArray.reverse()
        
        return retArray
    }
    
    // === Dijkstra ===
    func Dijkstra(s: Point) -> [Int:DPoint] {
        var Q: [Int:DPoint] = Initialize_Single_Source(s: s)
        var S: [Int:DPoint] = [Int:DPoint]()
        while !Q.isEmpty {
            let u = Extract_Min(Q: &Q)
            S[u.point.id] = u
            
            // get connected points
            var connectedDPoints = [DPoint]()
            if u.point.connectionIds.count > 0 {
                for vId in u.point.connectionIds {
                    if let cp = Q[vId] {
                        connectedDPoints.append(cp)
                    }
                }
            }
            
            for var v in connectedDPoints {
                Relax(u: u, v: &v)
            }
        }
        
        return S
    }
     
    
    func Initialize_Single_Source(s: Point) -> [Int:DPoint] {
        var ret = [Int:DPoint]()
        for (key, value) in LocationModel.shared.points {
            if value.isActive {
                if key == s.id {
                    ret[key] = (DPoint(0, value))
                } else {
                    ret[key] = (DPoint(Double(MAXFLOAT), value))
                }
            }
        }

        return ret
    }
    
    func Extract_Min(Q: inout [Int:DPoint]) -> DPoint {
        var curMinP = Q[Q.keys.first!]!
        
        for (_, value) in Q {
            if value.curWeight < curMinP.curWeight {
                curMinP = value
            }
        }
        
        // remove the min point from array
        Q.removeValue(forKey: curMinP.point.id)
        return curMinP
    }
    
    func Relax(u: DPoint, v: inout DPoint) {
        let dist_uv = distance(lat1: u.point.lat, lon1: u.point.lon, lat2: v.point.lat, lon2: v.point.lon)
        let tmp_weight = dist_uv + u.curWeight
        if tmp_weight < v.curWeight {
            v.curWeight = tmp_weight
            v.parentId = u.point.id
        }
    }
}
