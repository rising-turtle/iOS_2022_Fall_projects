//
//  ViewModel.swift
//  PathFinder
//
//  Created by Ryan Todd Pinsenschaum II on 11/10/22.
//

import Foundation

class LocationModel : ObservableObject{
    @Published var locations: [Int: Location] = [Int: Location]()
    @Published var points: [Int: Point] = [Int: Point]()
    
    // singleton
    static let shared: LocationModel = {
        return LocationModel()
    }()
    
    init() {
        readJSON()
    }
    
    // locations
    func readJSON() {
        //1. get the path to the json file with the app bundle
        let pathString = Bundle.main.path(forResource: "locations", ofType: "json")
        
        if let path = pathString {
            // 2. Create a URL path
            let url = URL(fileURLWithPath: path)
            do {
                // 3. Create a Data Object with the URL File to fetch the data
                let data = try Data(contentsOf: url)
                
                // 4. create a JSON Decoder
                let json_decoder = JSONDecoder()
                
                // !!! watch out the json format in the file !!!
                // 5. extract the model from json file
                let json_Data = try json_decoder.decode(Json_Data.self, from: data)
                
                for location in json_Data.locations {
                    locations[location.id] = location
                }
                for point in json_Data.points {
                    points[point.id] = point
                }
            } catch {
                print(error)
            }
        }
    }
}
