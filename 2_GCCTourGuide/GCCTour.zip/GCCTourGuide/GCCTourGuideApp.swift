//
//  GCCTourGuideApp.swift
//  GCCTourGuide
//
//  Created by Ethan Brown on 11/11/22.
//

import SwiftUI

@main
struct GCCTourGuideApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
